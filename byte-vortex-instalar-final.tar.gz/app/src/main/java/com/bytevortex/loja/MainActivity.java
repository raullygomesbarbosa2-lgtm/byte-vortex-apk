package com.bytevortex.loja;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Base64;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
 private WebView web;
 private ValueCallback<Uri[]> fileCallback;
 private String pendingApk, pendingDownload;
 private static final int PICK=5, SAVE=6;
 private static final String STATUS_ACTION="com.bytevortex.loja.INSTALL_STATUS";
 @Override public void onCreate(Bundle state){super.onCreate(state);web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(true);web.addJavascriptInterface(new Object(){
  @JavascriptInterface public void saveFile(String name,String data){runOnUiThread(()->saveWithPicker(name,data));}
  @JavascriptInterface public void installApk(String name,String data){runOnUiThread(()->beginInstall(name,data));}
 },"ByteVortex");web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){fileCallback=cb;Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(Intent.createChooser(i,"Escolha o arquivo"),PICK);return true;}});setContentView(web);web.loadUrl("file:///android_asset/index.html");}
 private byte[] decode(String data){return Base64.decode(data,Base64.DEFAULT);}
 private void beginInstall(String name,String data){pendingApk=data;if(Build.VERSION.SDK_INT>=26&&!getPackageManager().canRequestPackageInstalls()){Toast.makeText(this,"Permita instalar apps para continuar; depois volte para a Byte Vortex.",Toast.LENGTH_LONG).show();Intent i=new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName()));startActivity(i);return;}installPendingApk();}
 @Override protected void onResume(){super.onResume();if(pendingApk!=null&&(Build.VERSION.SDK_INT<26||getPackageManager().canRequestPackageInstalls()))installPendingApk();}
 private void installPendingApk(){if(pendingApk==null)return;String data=pendingApk;pendingApk=null;try{byte[] bytes=decode(data);PackageInstaller installer=getPackageManager().getPackageInstaller();PackageInstaller.SessionParams params=new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);int id=installer.createSession(params);PackageInstaller.Session session=installer.openSession(id);try(OutputStream out=session.openWrite("base.apk",0,bytes.length)){out.write(bytes);session.fsync(out);}Intent status=new Intent(this,MainActivity.class).setAction(STATUS_ACTION).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);PendingIntent pi=PendingIntent.getActivity(this,id,status,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_MUTABLE);session.commit(pi);session.close();}catch(Exception e){Toast.makeText(this,"Não foi possível iniciar a instalação: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(STATUS_ACTION.equals(intent.getAction())){int status=intent.getIntExtra(PackageInstaller.EXTRA_STATUS,PackageInstaller.STATUS_FAILURE);if(status==PackageInstaller.STATUS_PENDING_USER_ACTION){Intent confirmation=intent.getParcelableExtra(Intent.EXTRA_INTENT);if(confirmation!=null)startActivity(confirmation);}else if(status==PackageInstaller.STATUS_SUCCESS){Toast.makeText(this,"Instalação concluída.",Toast.LENGTH_LONG).show();}else{Toast.makeText(this,"Instalação cancelada ou não concluída.",Toast.LENGTH_LONG).show();}}}
 private void saveWithPicker(String name,String data){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,name);pendingDownload=data;startActivityForResult(i,SAVE);}
 @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==PICK&&fileCallback!=null){Uri[] out=result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null;fileCallback.onReceiveValue(out);fileCallback=null;}else if(req==SAVE){String payload=pendingDownload;pendingDownload=null;if(result==RESULT_OK&&data!=null&&data.getData()!=null&&payload!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(decode(payload));Toast.makeText(this,"Arquivo salvo; voltando à Byte Vortex.",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Erro ao salvar arquivo",Toast.LENGTH_LONG).show();}}}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
