window.BYTE_VORTEX_CONFIG = {};
